import React from 'react';
import { GlobalChangesSection } from './components/GlobalChangesSection';
import { RaleighDurhamSection } from './components/RaleighDurhamSection';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { IdeasSection } from './components/IdeasSection';
import { TeamSection } from './components/TeamSection';

const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        
        {/* Section 1: Raleigh-Durham Focus */}
        <RaleighDurhamSection />

        {/* Divider */}
        <div className="w-full my-12 sm:my-16"></div>

        {/* Section 2: Global Focus */}
        <GlobalChangesSection />

        {/* Divider */}
        <div className="w-full my-12 sm:my-16"></div>

        {/* Section 3: Ideas */}
        <IdeasSection />

        {/* Divider */}
        <div className="w-full my-12 sm:my-16"></div>

        {/* Section 4: Team */}
        <TeamSection />

      </main>
      <Footer />
    </div>
  );
};

export default App;