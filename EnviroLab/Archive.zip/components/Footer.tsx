import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer id="footer-links" className="w-full p-8 mt-16 border-t border-black text-xs">
      <div className="container mx-auto grid grid-cols-2 sm:grid-cols-4 gap-8">
        <div className="space-y-2">
          <h3 className="font-bold">shop</h3>
          <a href="#" className="block hover:underline">view all</a>
        </div>
        <div className="space-y-2">
          <h3 className="font-bold">info</h3>
          <a href="#" className="block hover:underline">about</a>
          <a href="#" className="block hover:underline">f.a.q.</a>
          <a href="#" className="block hover:underline">contact</a>
        </div>
        <div className="space-y-2">
          <h3 className="font-bold">legal</h3>
          <a href="#" className="block hover:underline">terms</a>
          <a href="#" className="block hover:underline">privacy</a>
          <a href="#" className="block hover:underline">accessibility</a>
        </div>
        <div className="space-y-2">
          <h3 className="font-bold">connect</h3>
          <a href="#" className="block hover:underline">mailing list</a>
          <a href="#" className="block hover:underline">community</a>
        </div>
      </div>
    </footer>
  );
};