import React, { useState, useCallback } from 'react';
import type { LatLng } from 'leaflet';
import { MapComponent } from './MapComponent';
import { Leaderboard } from './Leaderboard';

export const RaleighDurhamSection: React.FC = () => {
  const [userMarkers, setUserMarkers] = useState<LatLng[]>([]);

  const handleMapClick = useCallback((latlng: LatLng) => {
    setUserMarkers(prevMarkers => [...prevMarkers, latlng]);
  }, []);

  const clearUserMarkers = () => {
    setUserMarkers([]);
  };

  return (
    <section id="triangle-action" className="w-full flex flex-col items-center">
      <header className="mb-8 w-full">
        <h1 className="text-2xl font-bold text-black">Climate Action in the Triangle</h1>
        <p className="text-sm mt-1">Explore local initiatives and share your ideas for a sustainable Raleigh, Durham, and Chapel Hill.</p>
      </header>

      <div className="w-full relative aspect-w-16 aspect-h-9 min-h-[300px] sm:min-h-[400px] mb-8">
        <MapComponent
          initialCenter={[35.8437, -78.7853]} // Centered on the Triangle area
          initialZoom={10}
          userMarkers={userMarkers}
          onMapClick={handleMapClick}
        />
        {userMarkers.length > 0 && (
           <button
             onClick={clearUserMarkers}
             className="absolute top-4 right-4 z-[1000] bg-black text-white text-xs py-2 px-3 transition-colors hover:bg-gray-700"
             aria-label={`Clear ${userMarkers.length} markers`}
           >
             Clear Markers
           </button>
        )}
      </div>
    </section>
  );
};