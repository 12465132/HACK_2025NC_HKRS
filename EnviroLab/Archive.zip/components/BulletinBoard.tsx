import React from 'react';
import type { BulletinUpdate } from '../types';

interface BulletinBoardProps {
  updates: BulletinUpdate[];
  isLoading: boolean;
  error: string | null;
  hoveredLocationId: string | null;
  onItemHover: (id: string | null) => void;
}

export const BulletinBoard: React.FC<BulletinBoardProps> = ({ updates, isLoading, error, hoveredLocationId, onItemHover }) => {
  return (
    <div className="h-full">
      <h2 className="text-xl font-bold text-black mb-4">Global Changes</h2>
      <div className="relative">
        {isLoading && <p className="text-sm">Fetching latest updates...</p>}
        {error && <p className="text-sm text-red-500">{error}</p>}
        {!isLoading && !error && updates.length === 0 && (
          <p className="text-sm">No climate updates available for this view.</p>
        )}
        {!isLoading && !error && updates.length > 0 && (
          <ul className="space-y-4">
            {updates.map((update) => (
              <li 
                key={update.id} 
                className={`border-b border-gray-200 pb-3 transition-colors duration-200 ${hoveredLocationId === update.id ? 'bg-gray-100' : ''}`}
                onMouseEnter={() => onItemHover(update.id)}
                onMouseLeave={() => onItemHover(null)}
              >
                <a href={update.sourceUrl} target="_blank" rel="noopener noreferrer" className="block">
                  <h3 className="font-bold text-md text-black hover:underline">{update.title}</h3>
                  <p className="text-xs text-gray-600 font-medium">{update.location}</p>
                </a>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};