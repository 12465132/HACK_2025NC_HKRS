import React, { useEffect, useMemo, useState } from 'react';
import type { Idea } from '../types';

const initialIdeas: Idea[] = [
  { id: 2, title: 'Triangle Bike Highway Network', description: 'Create a network of protected bike lanes connecting Raleigh, Durham, and Chapel Hill.', upvotes: 45 },
  { id: 3, title: 'Solar Panel Bulk-Buying Program', description: 'Organize a community program to reduce the cost of residential solar panel installation through bulk purchasing.', upvotes: 32 },
  { id: 1, title: 'Community Gardens Initiative', description: 'Establish more community gardens in unused public spaces to promote local food production.', upvotes: 28 },
  { id: 4, title: 'Urban Tree Canopy Expansion', description: 'A plan to plant 10,000 new trees across the Triangle to reduce heat island effects and improve air quality.', upvotes: 19 },
];

const STORAGE_KEY = 'votedIdeaIds';

export const Leaderboard: React.FC = () => {
  const [ideas, setIdeas] = useState<Idea[]>(initialIdeas);
  const [newIdeaTitle, setNewIdeaTitle] = useState('');
  const [newIdeaDescription, setNewIdeaDescription] = useState('');
  const [sortBy, setSortBy] = useState<'top' | 'new'>('top');
  const [voted, setVoted] = useState<Set<number>>(new Set());

  // Load votes from localStorage once
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        setVoted(new Set<number>(JSON.parse(raw)));
      }
    } catch {}
  }, []);

  // Persist votes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(Array.from(voted)));
    } catch {}
  }, [voted]);

  const sortedIdeas = useMemo(() => {
    const sorted = [...ideas];
    if (sortBy === 'top') {
      sorted.sort((a, b) => b.upvotes - a.upvotes);
    } else {
      sorted.sort((a, b) => b.id - a.id);
    }
    return sorted;
  }, [ideas, sortBy]);

  const handleUpvote = (id: number) => {
    if (voted.has(id)) return; // already upvoted
    setIdeas(prev =>
      prev.map(i => (i.id === id ? { ...i, upvotes: i.upvotes + 1 } : i))
    );
    setVoted(prev => new Set(prev).add(id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newIdeaTitle.trim() || !newIdeaDescription.trim()) return;
    const nextId = ideas.length ? Math.max(...ideas.map(i => i.id)) + 1 : 1;
    const newIdea: Idea = {
      id: nextId,
      title: newIdeaTitle.trim(),
      description: newIdeaDescription.trim(),
      upvotes: 0,
    };
    setIdeas([newIdea, ...ideas]);
    setNewIdeaTitle('');
    setNewIdeaDescription('');
    setSortBy('new');
  };

  return (
    <div className="border-t border-black pt-8">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Community Ideas</h2>
        <div className="space-x-4 text-sm">
          <button
            className={sortBy === 'top' ? 'font-bold underline' : 'hover:underline'}
            onClick={() => setSortBy('top')}
            aria-pressed={sortBy === 'top'}
          >
            Top
          </button>
          <button
            className={sortBy === 'new' ? 'font-bold underline' : 'hover:underline'}
            onClick={() => setSortBy('new')}
            aria-pressed={sortBy === 'new'}
          >
            New
          </button>
        </div>
      </div>

      <ul className="mt-6 divide-y divide-black">
        {sortedIdeas.map(idea => {
          const disabled = voted.has(idea.id);
          return (
            <li key={idea.id} className="py-4 flex items-start justify-between">
              <div className="pr-4">
                <p className="font-bold">{idea.title}</p>
                <p className="text-sm text-gray-700 max-w-2xl">{idea.description}</p>
              </div>
              <button
                onClick={() => handleUpvote(idea.id)}
                disabled={disabled}
                aria-disabled={disabled}
                className={
                  'flex items-center space-x-2 border border-black px-3 py-2 text-sm ' +
                  (disabled ? 'bg-gray-200 cursor-not-allowed' : 'hover:bg-gray-100')
                }
                aria-label={disabled ? 'Upvoted' : 'Upvote'}
                title={disabled ? 'You already upvoted' : 'Upvote'}
              >
                <span>▲</span>
                <span>{idea.upvotes}</span>
              </button>
            </li>
          );
        })}
      </ul>

      <div className="mt-10">
        <button
          onClick={() => {
            const el = document.getElementById('idea-form');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          className="bg-black text-white font-bold py-2 px-4 hover:bg-gray-800"
        >
          Submit Your Idea
        </button>
      </div>

      <div id="idea-form" className="mt-6 border border-black p-4">
        <h3 className="font-bold mb-3">Share a new idea</h3>
        <form onSubmit={handleSubmit} className="space-y-3">
          <input
            value={newIdeaTitle}
            onChange={(e) => setNewIdeaTitle(e.target.value)}
            placeholder="Idea title"
            className="w-full p-2 border border-black focus:outline-none"
            required
          />
          <textarea
            value={newIdeaDescription}
            onChange={(e) => setNewIdeaDescription(e.target.value)}
            placeholder="Describe your idea"
            className="w-full p-2 border border-black focus:outline-none"
            rows={4}
            required
          />
          <button type="submit" className="w-full bg-black text-white font-bold py-2 hover:bg-gray-800">
            Submit Idea
          </button>
        </form>
      </div>
    </div>
  );
};
