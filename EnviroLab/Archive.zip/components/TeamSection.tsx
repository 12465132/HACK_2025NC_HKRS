import React from 'react';

const TEAM = [
  { name: 'Siddartha Bathineni', role: 'Project Lead / Maps', link: 'mailto:siddartha@example.com' },
  { name: 'Teammate 2', role: 'Data & Research', link: '#' },
  { name: 'Teammate 3', role: 'Frontend', link: '#' },
];

export const TeamSection: React.FC = () => {
  return (
    <section id="team" className="mt-16">
      <h2 className="text-xl font-bold mb-4">Team</h2>
      <ul className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {TEAM.map((m) => (
          <li key={m.name} className="border border-black p-4">
            <p className="font-bold">{m.name}</p>
            <p className="text-sm text-gray-600">{m.role}</p>
            <a className="text-xs underline" href={m.link} target="_blank" rel="noreferrer">Contact</a>
          </li>
        ))}
      </ul>
    </section>
  );
};
