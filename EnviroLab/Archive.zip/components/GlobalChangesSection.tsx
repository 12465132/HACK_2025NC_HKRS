import React, { useState, useCallback, useEffect } from 'react';
import type { LatLng, LatLngBounds } from 'leaflet';
import { MapComponent } from './MapComponent';
import { BulletinBoard } from './BulletinBoard';
import type { BulletinUpdate } from '../types';
import { GoogleGenAI, Type } from '@google/genai';

export const GlobalChangesSection: React.FC = () => {
  const [userMarkers, setUserMarkers] = useState<LatLng[]>([]);
  const [updates, setUpdates] = useState<BulletinUpdate[]>([]);
  const [hoveredLocationId, setHoveredLocationId] = useState<string | null>(null);
  const [mapView, setMapView] = useState<{ bounds: LatLngBounds; zoom: number } | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [cache, setCache] = useState(new Map<string, BulletinUpdate[]>());

  useEffect(() => {
    const fetchUpdates = async () => {
      if (!mapView) return;

      setIsLoading(true);
      setError(null);

      const { bounds, zoom } = mapView;
      
      const precision = Math.max(0, Math.floor(zoom / 3)); 
      const ne = bounds.getNorthEast();
      const sw = bounds.getSouthWest();
      const cacheKey = [
          Math.round(zoom),
          sw.lat.toFixed(precision),
          sw.lng.toFixed(precision),
          ne.lat.toFixed(precision),
          ne.lng.toFixed(precision)
      ].join('_');

      if (cache.has(cacheKey)) {
        setUpdates(cache.get(cacheKey)!);
        setIsLoading(false);
        return;
      }
      
      const resultCount = Math.min(25, 5 + Math.floor(zoom * 2.5));

      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
        const prompt = `Generate a list of ${resultCount} recent and significant updates on heat sustainability and climate action.
        - Each update must be a real event and have a verifiable source URL.
        - Each update must be geographically located within the following map bounds:
          - Northeast corner: latitude ${ne.lat}, longitude ${ne.lng}
          - Southwest corner: latitude ${sw.lat}, longitude ${sw.lng}
        - For each update, provide a title, a brief summary (1 sentence), location, its approximate latitude and longitude, and the source URL.`;

        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                updates: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      summary: { type: Type.STRING },
                      location: { type: Type.STRING },
                      lat: { type: Type.NUMBER },
                      lng: { type: Type.NUMBER },
                      sourceUrl: { type: Type.STRING },
                    },
                    required: ['title', 'summary', 'location', 'lat', 'lng', 'sourceUrl'],
                  },
                },
              },
            },
          },
        });

        const jsonString = response.text;
        const parsedData = JSON.parse(jsonString);
        const updatesWithId = (parsedData.updates || []).map((update: Omit<BulletinUpdate, 'id'>, index: number) => ({
          ...update,
          id: `${cacheKey}-${index}`,
        }));

        setUpdates(updatesWithId);
        setCache(prevCache => new Map(prevCache).set(cacheKey, updatesWithId));

      } catch (e) {
        console.error("Failed to fetch climate updates:", e);
        setError("Could not fetch climate updates for this area.");
        setUpdates([]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUpdates();
  }, [mapView, cache]);


  const handleMapClick = useCallback((latlng: LatLng) => {
    setUserMarkers(prevMarkers => [...prevMarkers, latlng]);
  }, []);

  const clearUserMarkers = () => {
    setUserMarkers([]);
  };

  const handleViewChange = useCallback((bounds: LatLngBounds, zoom: number) => {
    setMapView({ bounds, zoom });
  }, []);

  return (
    <section id="global-action" className="w-full">
      <header className="mb-8 w-full">
        <h1 className="text-2xl font-bold text-black">Global Climate Action Updates</h1>
        <p className="text-sm mt-1">Pan and zoom the map to discover climate actions worldwide.</p>
      </header>
      
      <div className="w-full grid grid-cols-1 lg:grid-cols-5 gap-8">
        <div className="lg:col-span-3">
          <div className="relative w-full aspect-w-16 aspect-h-9 min-h-[400px] sm:min-h-[500px]">
            <MapComponent
              initialCenter={[39.8283, -98.5795]}
              initialZoom={4}
              userMarkers={userMarkers}
              updates={updates}
              hoveredLocationId={hoveredLocationId}
              onMapClick={handleMapClick}
              onLocationHover={setHoveredLocationId}
              onViewChange={handleViewChange}
            />
            {userMarkers.length > 0 && (
              <button
                onClick={clearUserMarkers}
                className="absolute top-4 right-4 z-[1000] bg-black text-white text-xs py-2 px-3 transition-colors hover:bg-gray-700"
                aria-label={`Clear ${userMarkers.length} markers`}
              >
                Clear Markers
              </button>
            )}
          </div>
        </div>

        <div className="lg:col-span-2">
          <BulletinBoard
            updates={updates}
            isLoading={isLoading}
            error={error}
            hoveredLocationId={hoveredLocationId}
            onItemHover={setHoveredLocationId}
          />
        </div>
      </div>
    </section>
  );
};