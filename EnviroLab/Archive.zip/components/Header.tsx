import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="w-full p-4 border-b border-black">
      <nav className="container mx-auto flex items-center justify-between text-xs sm:text-sm">
        <a href="#" className="font-bold text-lg">CLIMATE ACTION</a>
        <div className="flex items-center space-x-4 sm:space-x-8">
          <a href="#triangle-action" className="hover:underline">THE TRIANGLE</a>
          <a href="#global-action" className="hover:underline">GLOBAL UPDATES</a>
          <a href="#ideas" className="hover:underline">IDEAS</a>
          <a href="#team" className="hover:underline">TEAM</a>
          <a href="#footer-links" className="hover:underline">INFO</a>
        </div>
      </nav>
    </header>
  );
};
