import React, { useEffect, useRef } from 'react';
import type { LatLng, Map as LeafletMap, LayerGroup, Marker, LatLngBounds } from 'leaflet';
import type { BulletinUpdate, RDU_LOCATION_TYPE } from '../types';

// Declare leaflet as a global variable
declare const L: any;

interface MapComponentProps {
  initialCenter: [number, number];
  initialZoom: number;
  userMarkers: LatLng[];
  updates?: BulletinUpdate[];
  rduLocations?: RDU_LOCATION_TYPE[];
  hoveredLocationId?: string | null;
  onMapClick: (latlng: LatLng) => void;
  onLocationHover?: (id: string | null) => void;
  onViewChange?: (bounds: LatLngBounds, zoom: number) => void;
}

// Helper component to avoid re-rendering issues
const MapRenderer: React.FC<MapComponentProps> = ({ 
  initialCenter, 
  initialZoom,
  userMarkers, 
  updates = [], 
  rduLocations = [],
  hoveredLocationId, 
  onMapClick, 
  onLocationHover, 
  onViewChange 
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletMap | null>(null);
  const userMarkersLayerRef = useRef<LayerGroup | null>(null);
  const updateMarkersLayerRef = useRef<LayerGroup | null>(null);
  const rduMarkersLayerRef = useRef<LayerGroup | null>(null);
  const markersRef = useRef<Map<string, Marker>>(new Map());
  const viewChangeTimeoutRef = useRef<number | null>(null);

  // Initialize map
  useEffect(() => {
    if (mapRef.current || !mapContainerRef.current) return;

    const map = L.map(mapContainerRef.current, { zoomControl: false }).setView(initialCenter, initialZoom);
    L.control.zoom({ position: 'bottomright' }).addTo(map);
    mapRef.current = map;

    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager_nolabels/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
      subdomains: 'abcd',
      maxZoom: 20,
    }).addTo(map);

    userMarkersLayerRef.current = L.layerGroup().addTo(map);
    updateMarkersLayerRef.current = L.layerGroup().addTo(map);
    rduMarkersLayerRef.current = L.layerGroup().addTo(map);

    if (onViewChange) {
      onViewChange(map.getBounds(), map.getZoom());
    }

    return () => {
        if (mapRef.current) {
            mapRef.current.remove();
            mapRef.current = null;
        }
    };
  }, [initialCenter, initialZoom, onViewChange]);

  // Handle view changes (pan/zoom) with debounce
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !onViewChange) return;
  
    const handleViewChange = () => {
      if (viewChangeTimeoutRef.current) {
        clearTimeout(viewChangeTimeoutRef.current);
      }
      viewChangeTimeoutRef.current = window.setTimeout(() => {
        onViewChange(map.getBounds(), map.getZoom());
      }, 500);
    };
  
    map.on('moveend', handleViewChange);
    map.on('zoomend', handleViewChange);
  
    return () => {
      map.off('moveend', handleViewChange);
      map.off('zoomend', handleViewChange);
      if (viewChangeTimeoutRef.current) {
        clearTimeout(viewChangeTimeoutRef.current);
      }
    };
  }, [onViewChange]);

  // Handle map click events
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    
    const clickHandler = (e: any) => onMapClick(e.latlng);
    map.on('click', clickHandler);

    return () => { map.off('click', clickHandler); };
  }, [onMapClick]);

  // Update user markers
  useEffect(() => {
    const layer = userMarkersLayerRef.current;
    if (!layer) return;

    layer.clearLayers();
    const userMarkerIcon = L.divIcon({
      html: `<div class="w-4 h-4 bg-black rounded-full"></div>`,
      className: 'bg-transparent border-0',
      iconSize: [16, 16],
      iconAnchor: [8, 8],
    });
    userMarkers.forEach(latlng => { L.marker(latlng, { icon: userMarkerIcon }).addTo(layer); });
  }, [userMarkers]);

  // Update climate action markers
  useEffect(() => {
    const layer = updateMarkersLayerRef.current;
    if (!layer || !mapRef.current || !onLocationHover) return;

    layer.clearLayers();
    markersRef.current.clear();
    
    const updateMarkerIcon = L.divIcon({
        html: `<div class="w-4 h-4 bg-blue-600 rounded-full"></div>`,
        className: 'bg-transparent border-0',
        iconSize: [16, 16],
        iconAnchor: [8, 8],
    });

    updates.forEach(update => {
        const marker = L.marker([update.lat, update.lng], { icon: updateMarkerIcon })
            .addTo(layer)
            .bindPopup(`<b>${update.title}</b>`);
            
        marker.on('mouseover', () => onLocationHover(update.id));
        marker.on('mouseout', () => onLocationHover(null));
        marker.on('click', () => {
          if (update.sourceUrl) {
            window.open(update.sourceUrl, '_blank', 'noopener,noreferrer');
          }
        });

        markersRef.current.set(update.id, marker);
    });
  }, [updates, onLocationHover]);

  // Handle hovered location popups
  useEffect(() => {
    if (!onLocationHover) return;

    markersRef.current.forEach((marker, id) => {
      if (hoveredLocationId !== id) {
        marker.closePopup();
      }
    });

    if (hoveredLocationId) {
        const marker = markersRef.current.get(hoveredLocationId);
        if (marker && !marker.isPopupOpen()) {
            marker.openPopup();
        }
    }
  }, [hoveredLocationId, onLocationHover]);


  return <div ref={mapContainerRef} className="h-full w-full" />;
};

export const MapComponent = React.memo(MapRenderer);