import React from 'react';
import { Leaderboard } from './Leaderboard';

export const IdeasSection: React.FC = () => {
  return (
    <section id="ideas" className="mt-12">
      <Leaderboard />
    </section>
  );
};
