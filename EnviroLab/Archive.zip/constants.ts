
import type { LocationPoint } from './types';

export const INITIAL_LOCATIONS: LocationPoint[] = [
  { lat: 48.8584, lng: 2.2945, name: 'Eiffel Tower', description: 'Iconic landmark in Paris, France.' },
  { lat: 40.7128, lng: -74.0060, name: 'New York City', description: 'The city that never sleeps.' },
  { lat: 35.6895, lng: 139.6917, name: 'Tokyo', description: 'The bustling capital of Japan.' },
  { lat: -33.8688, lng: 151.2093, name: 'Sydney', description: 'Home of the famous Opera House.' },
  { lat: -22.9519, lng: -43.2105, name: 'Christ the Redeemer', description: 'Art Deco statue in Rio de Janeiro.' },
  { lat: 51.5072, lng: -0.1276, name: 'London', description: 'The capital city of England.' },
  { lat: 29.9792, lng: 31.1342, name: 'Great Pyramid of Giza', description: 'The oldest of the Seven Wonders.' },
];
