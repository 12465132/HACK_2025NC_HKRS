export interface LocationPoint {
  lat: number;
  lng: number;
  name: string;
  description: string;
}

export interface BulletinUpdate {
  id: string;
  title: string;
  summary: string;
  location: string;
  lat: number;
  lng: number;
  sourceUrl: string;
}

export interface Idea {
  id: number;
  title: string;
  description: string;
  upvotes: number;
}

export interface RDU_LOCATION_TYPE {
  id: string;
  name: string;
  description: string;
  lat: number;
  lng: number;
  link: string;
}